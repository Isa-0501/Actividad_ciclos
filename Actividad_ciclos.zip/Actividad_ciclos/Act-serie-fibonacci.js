var fin = parseInt(prompt("Ingresa hasta que número llegará la secuencia"))
var anterior = 1
var presente = 0
var resultado = 1

for (i=1; resultado<=fin; i++){
    console.log (resultado);
    resultado = anterior + presente;
    anterior = presente;
    presente = resultado;
}