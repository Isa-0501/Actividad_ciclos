let num = 1
let resultado = 0

for (num=0; num<=50; num+=2){
    resultado = resultado + num
    console.log (num)
}
console.log (" El resultado total es " + resultado)