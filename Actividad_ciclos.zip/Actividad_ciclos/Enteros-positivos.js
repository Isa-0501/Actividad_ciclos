var inicio = parseInt (prompt("Digite el numero de inicio"))
var fin = parseInt (prompt("Digite el numero de fin"))
var suma = 0
var resultado = 0

for (i=inicio; i<=fin; i++){
    console.log (i)
}
for (i=inicio; i<=fin; i++){
    suma = suma + i
}
console.log ("Total de la suma de éstos números es: " + suma)