var entero = parseInt (prompt("Digite un número entero positivo"))
var primo = 1

if (entero<2){
    primo = 0
}

for (var i=2; i<entero; i++){
    if (primo==1 && Math.floor(entero/i)*i==entero){
        primo = 0
    }
}
if (primo==1){
    console.log (entero+" si es un número primo")
}else{
    console.log (entero+" no es un número primo")
}
